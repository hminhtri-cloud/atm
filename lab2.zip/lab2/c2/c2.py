from Crypto.Cipher import AES


KEY = b"1234567890123456"
IV = b"6543210987654321"
PLAINTEXT = b"UIT_LAB_UIT_LAB_UIT_LAB_UIT_LAB_"


def print_blocks(label, ciphertext):
    print(f"{label}: {ciphertext.hex()}")
    for index in range(0, len(ciphertext), AES.block_size):
        print(f"  block {index // AES.block_size + 1}: {ciphertext[index:index + AES.block_size].hex()}")


def main():
    if len(PLAINTEXT) % AES.block_size:
        raise ValueError("Plaintext must contain complete AES blocks")

    ecb_ciphertext = AES.new(KEY, AES.MODE_ECB).encrypt(PLAINTEXT)
    cbc_ciphertext = AES.new(KEY, AES.MODE_CBC, IV).encrypt(PLAINTEXT)

    print_blocks("ECB", ecb_ciphertext)
    print_blocks("CBC", cbc_ciphertext)

    ecb_blocks = [ecb_ciphertext[i:i + 16] for i in range(0, len(ecb_ciphertext), 16)]
    cbc_blocks = [cbc_ciphertext[i:i + 16] for i in range(0, len(cbc_ciphertext), 16)]
    print(f"ECB blocks giong nhau: {ecb_blocks[0] == ecb_blocks[1]}")
    print(f"CBC blocks giong nhau: {cbc_blocks[0] == cbc_blocks[1]}")


if __name__ == "__main__":
    main()
